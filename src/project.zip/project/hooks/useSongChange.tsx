import React, { useState } from 'react'
import playListSongs from '../data/playlists.json'

interface Album {
    name: string;
    artist: string;
    year: number;
    tracks: Song[];
}

interface Song {
    name: string;
    url: string;
    duration: number;
}

export const useSongChange = () => {
  
    const [tabValue, setTabValue] = useState(0);
    const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
        setTabValue(newValue)
    }


    const [album, setAlbum] = useState<Album | null>(null);
    const handleChangeAlbum = (albumSelected: string) => {
        const newAlbum = playListSongs.playlists.find(album => album.name === albumSelected) || null
        setAlbum(newAlbum);
    };


    const [song, setSong] = useState<Song | null>(null);

    const handleSelectedSong = (songSelected: string) => {
        if (!album) return;
        setSongError(false);
        const newSong = album.tracks.find(song => song.name === songSelected) || null
        
        if(newSong){
            const audio = new Audio(newSong.url);
            audio.onerror = () => setSongError(true);
            audio.load();
        }
        setSong(newSong);
        setAlbumSongData({albumName: album?.name, albumArtist: album?.artist})
    }

    const handleChangeSong = (btnPressedVal:number): void => {
        const trackIndex = album?.tracks.findIndex((csong) => csong.name === song?.name) || 0;
        const nextSong = (btnPressedVal === 1 ? album?.tracks[trackIndex + 1].name : album?.tracks[trackIndex - 1].name) || ""
        handleSelectedSong(nextSong);
    }


    const [albumSongData, setAlbumSongData] = useState({albumName:"", albumArtist:""});

    const [songError, setSongError] = useState(false);

    return {
        tabValue,
        handleTabChange,
        album,
        song,
        handleChangeAlbum,
        handleSelectedSong,
        handleChangeSong,
        albumSongData,
        songError
    }
}
